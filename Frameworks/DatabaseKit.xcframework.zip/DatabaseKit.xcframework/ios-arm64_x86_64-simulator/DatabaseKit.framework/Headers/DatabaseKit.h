//
//  DatabaseKit.h
//  DatabaseKit
//
//  Created by Divya Prakash on 10/02/24.
//

#import <Foundation/Foundation.h>

//! Project version number for DatabaseKit.
FOUNDATION_EXPORT double DatabaseKitVersionNumber;

//! Project version string for DatabaseKit.
FOUNDATION_EXPORT const unsigned char DatabaseKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DatabaseKit/PublicHeader.h>


